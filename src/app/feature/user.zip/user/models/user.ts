interface User{
    id : string,
    name : string,
    password : string,
    latitude : number,
    description : string,
    status : boolean,

}

export { User};